#########################################################
## test.R    A script for testing the metmatch algorithm
#########################################################

## This script is to help the reviewers get started with using MetMatch.
##  There are 3 main sections, Installation, Running MetMatch, and Database Construction

#########################################################
## I. INSTALLATION
#########################################################
## REQUIREMENTS:   If needed, install the XCMS/CAMERA, MASS, RColorBrewer and fields packages
install.packages(c("MASS","RColorBrewer","fields"))

## CAMERA only needed if you plan to run XCMS/CAMERA on mzXML files
## We have provided CAMERA files from this analysis.
#source("http://bioconductor.org/biocLite.R")
#biocLite("CAMERA")

## Install metmatch from the source file
## The source has been included in this review_test folder

## Set your working directory containing the  MetMatch_0.91.tar.gz archive and the cam.cv files
##   Run the following at the RGui prompt after typing your working directory between the quotes:
setwd("<Full path to this folder>")

## install metmatch
install.packages("MetMatch_0.92.tar.gz", repos = NULL, type="source")
library(MetMatch)

#########################################################
## II. RUNNING METMATCH
#########################################################
##  First the database must be loaded.  We provide a target feature library (TFL) with the package,
##   and then quickest, easiest way to get started is to load this TFL of theoretical isotope ratios.
##  Should a user decide to want to build a custom TFL (eg for plant work), an example of how to 
##   do so is provided at the end of this script.

## Load the TFL- database 
data(TFL)

## To demonstrate the algorithm, there are 2 sets of commands below,
##  1 for running all samples in a folder (batch mode) and the second for searching a single file

##############
## BATCH MODE
##############

## For batch running of several samples. we have provided 5 XCMS/CAMERA files, the primary input to 
##  the algorithm. The runs in decoy mode are ~3 minutes / file (<1 min with "nodecoy" option)
##  MetMatch recognizes these as ".cam.csv" files when run in batch mode. For batch mode, data
##   can be aligned, so an alignment function is included.
##   Results will be placed in the testdata sub folder with plots.
## The 'N' option is for when multiple data files have been run through XCMS and alinged
##  resulting in a table of intensity values.  For our demonstration data and this manuscript,
##  N always equals 1.

data(TFL)   ## loads the database
run.metmatch("testdata/lp", DB=TFL, save = TRUE, score.method = "best", run.type = "decoy",N=1)  
#run.metmatch("testdata", DB=TFL, save = TRUE, score.method = "best", run.type = "nodecoy")  

alignedresults = align.MetMatchResults("testdata/lp",maxRtDiff=60,cutoff=1,N=1)

####################
## SINGLE FILE MODE
####################

## First the camera files have to be converted to a format that metmatch recognizes
## The 'N' option is for when multiple data files have been run through XCMS and aligned
##  resulting in a table of intensity values.  For our demonstration data and this manuscript,
##  N always equals 1.

Q.data = convert.camera.file("testdata/lp/MTBE_Lipid_Inst_QC_HEK293-r001.cam.csv",N=1)

## Now the file can be searched (results in the current working directory):
data(TFL)   ## loads the database
metmatch(Q.data, DB=TFL, mass.tol = 50, rel.int.tol = 0.5, Mono = FALSE,
  score.method = "best", run.type = "nodecoy", score.type = "both", out.file.name = "MTBE_Lipid_Inst_QC_HEK293-r001")

## Settings are explained using the R manual:
?metmatch

#########################
### III. DATABASE CONSTRUCTION
#########################

## Database construction can take a while, and requires the Emass (Rockwood et al) executable program 
##  in your working directory were you will be constructing the TFL or database. Additionally, Emass
##  provides a prebuilt program for windows OS, which is what we use here.  Users on linux/apple OS
##  will need to precompile Emass for their platform, following their instructions.   Their program, 
##  is availble from http://www.helsinki.fi/science/lipids/software.html . The TFL building function
##  requires a unique list of formulae, which are the input to Emass. We have provided a sample list
##  of formulae, but if you wish, you can compile your own list, following the format seen in the example 
##  file.

## First read the list of formulae, then clean the formulae of those containing R groups, D's, 
##   and missing values
formulae = read.delim("formulae.txt")
formulae = clean.formulae(formulae)

## Now build the TFL using the build.DB.emass command
TFL = build.DB.emass(k=6,formulae)

## If you want to look at the TFL entry build for a single formulae:
run.emass(formulae[1])





